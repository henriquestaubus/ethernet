// =============================================================
// tb_reset_PHY.sv
// Testa se phyreset fica em 0 por RESET_CYCLES ciclos
// e depois vai para 1.
// Parâmetro reduzido para simulação rápida.
// =============================================================
`timescale 1ns/1ps

module tb_reset_PHY;

    // Parâmetro reduzido — em vez de 10_000_000 usamos 20 ciclos
    // para a simulação ser rápida. Troca no DUT também.
    localparam RESET_CYCLES = 20;
    localparam CLK_PERIOD   = 10; // 100 MHz

    logic clk;
    logic reset;
    logic phyreset;

    // --------------------------------------------------------
    // DUT — instancia com parâmetro reduzido
    // --------------------------------------------------------
    reset_PHY #(
        .RESET_CYCLES(RESET_CYCLES)
    ) u_dut (
        .clk      (clk),
        .reset    (reset),
        .phyreset (phyreset)
    );

    // --------------------------------------------------------
    // Clock
    // --------------------------------------------------------
    initial clk = 0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // --------------------------------------------------------
    // Estímulos
    // --------------------------------------------------------
    initial begin
        $display("=== TB reset_PHY iniciado ===");

        // Aplica reset do sistema
        reset = 1;
        repeat(5) @(posedge clk);
        reset = 0;

        // Verifica que phyreset está em 0 durante a contagem
        @(posedge clk);
        if (phyreset !== 1'b0)
            $error("FALHA: phyreset deveria ser 0 logo apos reset");
        else
            $display("OK: phyreset em 0 apos reset do sistema");

        // Espera RESET_CYCLES ciclos + margem
        repeat(RESET_CYCLES + 5) @(posedge clk);

        // Verifica que phyreset foi para 1
        if (phyreset !== 1'b1)
            $error("FALHA: phyreset deveria ser 1 apos %0d ciclos", RESET_CYCLES);
        else
            $display("OK: phyreset em 1 apos %0d ciclos", RESET_CYCLES);

        // Testa re-reset: se reset voltar, phyreset deve cair
        reset = 1;
        @(posedge clk);
        @(posedge clk);
        if (phyreset !== 1'b0)
            $error("FALHA: phyreset deveria voltar a 0 com reset ativo");
        else
            $display("OK: phyreset volta a 0 com reset ativo");

        reset = 0;

        $display("=== TB reset_PHY finalizado ===");
        $finish;
    end

    // --------------------------------------------------------
    // Timeout de segurança
    // --------------------------------------------------------
    initial begin
        #((RESET_CYCLES + 50) * CLK_PERIOD);
        $error("TIMEOUT: simulação não terminou");
        $finish;
    end

endmodule // tb_reset_PHY
