`timescale 1ns/1ps

module tb_tx_interface;

    localparam CLK_PERIOD = 20;

    logic clk;
    logic reset;
    logic phy_ready;
    logic txen;
    logic [7:0] tx_byte;
    logic tx_last;

    logic tx_ready;
    logic [1:0] txd;

    // DUT
    tx_interface dut (
        .clk(clk),
        .reset(reset),
        .phy_ready(phy_ready),
        .txen(txen),
        .tx_byte(tx_byte),
        .tx_last(tx_last),
        .tx_ready(tx_ready),
        .txd(txd)
    );

    // Clock
    initial clk = 0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // Monitor
    always @(posedge clk) begin
        $display("[%0t] txd = %b | tx_ready = %b", 
                  $time, txd, tx_ready);
    end

    initial begin

        $display("=== INICIO TESTE TX ===");

        // Inicialização
        reset     = 1;
        phy_ready = 0;
        txen      = 0;
        tx_byte   = 8'b0;
        tx_last   = 0;

        repeat(2) @(posedge clk);

        // Libera sistema
        reset     = 0;
        phy_ready = 1;

        @(posedge clk);

        // ------------------------------------------------
        // Teste 1
        // Byte: 11010010
        //
        // Esperado nos dibits:
        // 10
        // 00
        // 01
        // 11
        // ------------------------------------------------

        
        tx_byte = 8'b11010010;
        tx_last = 0;
        txen = 1;
        @(posedge clk);
        txen = 0;
        // Aguarda transmissão
        repeat(6) @(posedge clk);

        

        // ------------------------------------------------
        // Teste 2
        // Outro byte
        // ------------------------------------------------

        @(posedge clk);
        tx_byte = 8'b10011100;
         txen = 1;
        @(posedge clk);
         txen = 0;
        repeat(5) @(posedge clk);
        tx_last = 1;
        @(posedge clk);

       

        repeat(3) @(posedge clk);

        $display("=== FIM TESTE TX ===");

        $finish;
    end

endmodule