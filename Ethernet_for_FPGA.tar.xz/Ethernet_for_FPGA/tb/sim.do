if {[file isdirectory work]} {vdel -all -lib work}
vlib work
vmap work work

vlog -work work ../src/reset_PHY.sv
vlog -work work ../src/rmii_phy_ctrl.sv
vlog -work work ../src/rx_interface.sv
vlog -work work ../src/tx_interface.sv
vlog -work work ../src/mac_rx.sv
vlog -work work ../src/ethernet_frame_tx.sv
vlog -work work ../src/crc_inst.sv
vlog -work work ../src/arp_reply.sv
vlog -work work ../src/ethernet_tx_top.sv
vlog -work work tb_ethernet_tx_top.sv




vsim -voptargs=+acc work.tb_ethernet_tx_top

quietly set StdArithNoWarnings 1
quietly set StdVitalGlitchNoWarnings 1

add wave *
run 25ms