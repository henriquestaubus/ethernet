`timescale 1ns/1ps

module tb_rx_interface;

    localparam CLK_PERIOD = 20;

    logic clk;
    logic reset;
    logic phy_ready;
    logic crs;
    logic dv;
    logic rxerr;
    logic [1:0] rxd;

    logic [7:0] rx_byte;
    logic       rx_valid;
    logic       rx_last;
    logic       rx_error;

    // DUT
    rx_interface dut (
        .clk(clk),
        .reset(reset),
        .phy_ready(phy_ready),
        .crs(crs),
        .dv(dv),
        .rxerr(rxerr),
        .rxd(rxd),
        .rx_byte(rx_byte),
        .rx_valid(rx_valid),
        .rx_last(rx_last),
        .rx_error(rx_error)
    );

    // Clock
    initial clk = 0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // Monitor
    always @(posedge clk) begin
        if(rx_valid)
            $display("[%0t] rx_byte = %b", $time, rx_byte);

        if(rx_last)
            $display("[%0t] rx_last = 1", $time);

        if(rx_error)
            $display("[%0t] rx_error = 1", $time);
    end

    initial begin

        $display("=== INICIO TESTE ===");

        // Inicialização
        reset     = 1;
        phy_ready = 0;
        crs       = 0;
        dv        = 0;
        rxerr     = 0;
        rxd       = 2'b00;

        repeat(2) @(posedge clk);

        // Libera sistema
        reset     = 0;
        phy_ready = 1;

        @(posedge clk);

        // Inicia recepção
        crs = 1;
        dv  = 1;

        // Envia:
        // 11 01 00 10
        // Esperado:
        // 11010010

        @(posedge clk); rxd = 2'b11;
        @(posedge clk); rxd = 2'b01;
        @(posedge clk); rxd = 2'b00;
        @(posedge clk); rxd = 2'b10;

        @(posedge clk);

        // Verificação
        if(rx_byte == 8'b11010010)
            $display("OK: byte correto");
        else
            $error("ERRO: byte recebido = %b", rx_byte);

        // Finaliza frame
        crs = 0;
        dv  = 0;

        @(posedge clk);

        // Teste rxerr
        crs   = 1;
        dv    = 1;
        rxerr = 1;

        @(posedge clk);

        if(rx_error)
            $display("OK: rx_error funcionando");
        else
            $error("ERRO: rx_error nao ativou");

        rxerr = 0;
        crs   = 0;
        dv    = 0;

        repeat(3) @(posedge clk);

        $display("=== FIM TESTE ===");

        $finish;
    end

endmodule