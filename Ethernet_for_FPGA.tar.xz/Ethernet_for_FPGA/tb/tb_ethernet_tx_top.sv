`timescale 1ns/1ps

module tb_ethernet_tx_top;

logic clk;
logic clk50;
logic reset;

logic phy_ready;

logic [7:0] payload_data;
logic       payload_valid;
logic       payload_last;

logic [1:0] rmii_txd;
logic       clkin;


// ======================================================
// DUT
// ======================================================

ethernet_tx_top dut (

    .clk(clk),
    .reset(reset),
    .clk50(clk50),

    .phy_ready(phy_ready),

    .payload_data(payload_data),
    .payload_valid(payload_valid),
    .payload_last(payload_last),

    .rmii_txd(rmii_txd),
    .clkin(clkin)

);


// ======================================================
// CLOCKS
// ======================================================

initial begin
    clk = 0;
    forever #10 clk = ~clk;
end

initial begin
    clk50 = 0;
    forever #10 clk50 = ~clk50;
end


// ======================================================
// STIMULUS
// ======================================================

initial begin

    $dumpfile("tb_ethernet_tx_top.vcd");
    $dumpvars(0, tb_ethernet_tx_top);

    // init
    reset         = 1;

    phy_ready     = 1;

    payload_data  = 0;
    payload_valid = 0;
    payload_last  = 0;

    // reset
    #100;
    reset = 0;

    #40;

    // ==========================================
    // SEND "HELLO"
    // ==========================================

    send_byte("H", 0);
    send_byte("E", 0);
    send_byte("L", 0);
    send_byte("L", 0);
    send_byte("O", 1);

    @(posedge clk);

    payload_valid <= 0;
    payload_last  <= 0;

    #5000;

    $finish;

end


// ======================================================
// TASK SEND BYTE
// ======================================================

task send_byte(

    input [7:0] data,
    input       last

);

begin

    @(posedge clk);

    payload_data  <= data;
    payload_valid <= 1;
    payload_last  <= last;

    @(posedge clk);

    payload_valid <= 0;
    payload_last  <= 0;

end

endtask


// ======================================================
// MONITOR
// ======================================================

always @(posedge clk) begin

    if(dut.tx_valid) begin

        $display(
            "[%0t] TXD=%b",
            $time,
            rmii_txd
        );

    end

end


endmodule