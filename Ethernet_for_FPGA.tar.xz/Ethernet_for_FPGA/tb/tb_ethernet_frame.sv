`timescale 1ns/1ps

module tb_ethernet_frame_tx;

logic clk;
logic reset;

logic [7:0] payload_data;
logic       payload_valid;
logic       payload_last;

logic       tx_ready;

logic [7:0] tx_byte;
logic       tx_valid;
logic       frame_done;


// ======================================================
// DUT
// ======================================================

ethernet_frame_tx dut (

    .clock(clk),
    .reset(reset),

    .payload_data(payload_data),
    .payload_valid(payload_valid),
    .payload_last(payload_last),

    .tx_ready(tx_ready),

    .tx_byte(tx_byte),
    .tx_valid(tx_valid),
    .frame_done(frame_done)

);


// ======================================================
// CLOCK
// ======================================================

initial begin
    clk = 0;
    forever #10 clk = ~clk; // 50 MHz
end


// ======================================================
// STIMULUS
// ======================================================

initial begin

    // dump waveform
    $dumpfile("tb_ethernet_frame_tx.vcd");
    $dumpvars(0, tb_ethernet_frame_tx);

    // init
    reset         = 1;

    payload_data  = 0;
    payload_valid = 0;
    payload_last  = 0;

    tx_ready      = 1;

    // reset
    #100;
    reset = 0;

    #40;

// ==========================================
// SEND "HELLO"
// ==========================================

send_byte("H", 0);
send_byte("E", 0);
send_byte("L", 0);
send_byte("L", 0);
send_byte("O", 1);

@(posedge clk);

payload_valid <= 0;
payload_last  <= 0;


#5000;
$finish;

end


// ======================================================
// TASK SEND BYTE
// ======================================================

task send_byte(

    input [7:0] data,
    input       last

);

begin

    @(posedge clk);

    payload_data  <= data;
    payload_valid <= 1;
    payload_last  <= last;

    @(posedge clk);

    payload_valid <= 0;
    payload_last  <= 0;

end

endtask


// ======================================================
// MONITOR
// ======================================================

always @(posedge clk) begin

    if(tx_valid && tx_ready) begin

        $display("[%0t] STATE=%0d TX=%02X VALID=%0d",
         $time,
         dut.EA,
         tx_byte,
         tx_valid);

    end

end


endmodule