module ethernet_frame_tx(

    input       logic           clock,
    input       logic           reset,
    input       logic   [7:0]   payload_data,
    input       logic           payload_valid,
    input       logic           payload_last,
    input       logic           tx_ready,
    input       logic           phy_ready,

    output      logic   [7:0]   tx_byte,
    output      logic           tx_valid,
    output      logic           frame_done
);


logic [3:0] preamble_cnt;
logic [3:0] header_cnt;
logic [1:0] crc_cnt;
logic [4:0] ifg_cnt;

localparam [47:0] DEST_MAC  = 48'hFFFFFFFFFFFF;
localparam [47:0] SRC_MAC   = 48'h123456789ABC;
localparam [15:0] ETHERTYPE = 16'h0800;


logic [7:0] payload_mem [0:255];
logic [7:0] write_ptr;
logic [7:0] read_ptr;
logic [7:0] payload_size;


logic        crc_reset;
logic        crc_valid;
logic [7:0]  crc_data;
logic [31:0] crc_out;

crc32_ethernet crc_inst (
    .clk       (clock),
    .reset     (crc_reset),
    .data_in   (crc_data),
    .data_valid(crc_valid),
    .crc_out   (crc_out)
);

typedef enum logic [2:0] {
    IDLE,
    PREAMBLE,
    HEADER,
    PAYLOAD,
    CRC,
    IFG
} state_t;

state_t EA;


always_comb begin
    case(EA)
        PREAMBLE: begin
            tx_byte = (preamble_cnt < 7) ? 8'h55 : 8'hD5;
        end
        HEADER: begin
            case(header_cnt)
                0:       tx_byte = DEST_MAC[47:40];
                1:       tx_byte = DEST_MAC[39:32];
                2:       tx_byte = DEST_MAC[31:24];
                3:       tx_byte = DEST_MAC[23:16];
                4:       tx_byte = DEST_MAC[15:8];
                5:       tx_byte = DEST_MAC[7:0];
                6:       tx_byte = SRC_MAC[47:40];
                7:       tx_byte = SRC_MAC[39:32];
                8:       tx_byte = SRC_MAC[31:24];
                9:       tx_byte = SRC_MAC[23:16];
                10:      tx_byte = SRC_MAC[15:8];
                11:      tx_byte = SRC_MAC[7:0];
                12:      tx_byte = ETHERTYPE[15:8];
                13:      tx_byte = ETHERTYPE[7:0];
                default: tx_byte = 8'h00;
            endcase
        end
        PAYLOAD: begin
            tx_byte = payload_mem[read_ptr];
        end
        CRC: begin
            case(crc_cnt)
                0:       tx_byte = crc_out[7:0];
                1:       tx_byte = crc_out[15:8];
                2:       tx_byte = crc_out[23:16];
                3:       tx_byte = crc_out[31:24];
                default: tx_byte = 8'h00;
            endcase
        end
        default: tx_byte = 8'h00;
    endcase
end

always_ff @(posedge clock) begin
    // defaults de 1 ciclo
    crc_reset <= 0;
    crc_valid <= 0;

    if(reset || !phy_ready) begin
        EA           <= IDLE;
        tx_valid     <= 0;
        preamble_cnt <= 0;
        header_cnt   <= 0;
        crc_cnt      <= 0;
        ifg_cnt      <= 0;
        frame_done   <= 0;
        write_ptr    <= 0;
        read_ptr     <= 0;
        payload_size <= 0;
    end
    else begin
        case(EA)

            IDLE: begin
                tx_valid   <= 0;
                frame_done <= 0;

                if(payload_valid) begin
                    payload_mem[write_ptr] <= payload_data;

                    if(payload_last) begin
                        payload_size <= write_ptr + 1;
                        write_ptr    <= 0;
                        read_ptr     <= 0;
                        preamble_cnt <= 0;
                        crc_reset    <= 1;      // pulsa reset do CRC antes de transmitir
                        EA           <= PREAMBLE;
                    end
                    else begin
                        write_ptr <= write_ptr + 1;
                    end
                end
            end

            PREAMBLE: begin
                if(tx_ready) begin
                    tx_valid <= 1;

                    if(preamble_cnt == 7) begin
                        // SFD transmitido (tx_byte combinacional já mostra 0xD5)
                        header_cnt <= 0;
                        EA         <= HEADER;
                    end
                    else begin
                        preamble_cnt <= preamble_cnt + 1;
                    end
                end
            end

            HEADER: begin
                if(tx_ready) begin
                    tx_valid  <= 1;
                    crc_valid <= 1;

                    // crc_data alimentado diretamente — mesmo valor que tx_byte
                    case(header_cnt)
                        0:  crc_data <= DEST_MAC[47:40];
                        1:  crc_data <= DEST_MAC[39:32];
                        2:  crc_data <= DEST_MAC[31:24];
                        3:  crc_data <= DEST_MAC[23:16];
                        4:  crc_data <= DEST_MAC[15:8];
                        5:  crc_data <= DEST_MAC[7:0];
                        6:  crc_data <= SRC_MAC[47:40];
                        7:  crc_data <= SRC_MAC[39:32];
                        8:  crc_data <= SRC_MAC[31:24];
                        9:  crc_data <= SRC_MAC[23:16];
                        10: crc_data <= SRC_MAC[15:8];
                        11: crc_data <= SRC_MAC[7:0];
                        12: crc_data <= ETHERTYPE[15:8];
                        13: crc_data <= ETHERTYPE[7:0];
                        default: crc_data <= 8'h00;
                    endcase

                    if(header_cnt == 13) begin
                        header_cnt <= 0;
                        read_ptr   <= 0;
                        EA         <= PAYLOAD;
                    end
                    else begin
                        header_cnt <= header_cnt + 1;
                    end
                end
            end

            PAYLOAD: begin
                if(tx_ready) begin
                    tx_valid  <= 1;
                    crc_data  <= payload_mem[read_ptr];
                    crc_valid <= 1;

                    if(read_ptr == payload_size - 1) begin
                        read_ptr <= 0;
                        crc_cnt  <= 0;
                        EA       <= CRC;
                    end
                    else begin
                        read_ptr <= read_ptr + 1;
                    end
                end
            end

    
            CRC: begin
                if(tx_ready) begin
                    tx_valid <= 1;

                    if(crc_cnt == 3) begin
                        crc_cnt <= 0;
                        EA      <= IFG;
                    end
                    else begin
                        crc_cnt <= crc_cnt + 1;
                    end
                end
            end

            IFG: begin
                tx_valid <= 0;
                ifg_cnt  <= ifg_cnt + 1;

                if(ifg_cnt == 11) begin
                    ifg_cnt    <= 0;
                    frame_done <= 1;
                    EA         <= IDLE;
                end
            end

        endcase
    end
end

endmodule