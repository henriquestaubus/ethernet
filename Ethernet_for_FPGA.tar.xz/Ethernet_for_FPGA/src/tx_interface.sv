module tx_interface (
    input  logic        clk,
    input  logic        reset,
    input  logic        phy_ready,  
    input  logic        txen,
    input  logic [7:0]  tx_byte,   
    input  logic        tx_last,
    output logic        tx_ready,  
    output logic [1:0]  txd,
    output logic        tx_en
);

    typedef enum logic [1:0] {
        IDLE,
        LOAD,
        SEND,
        WAIT
    } state_t;

    state_t EA;

    logic [7:0]  shift_reg;
    logic [1:0]  dibit_cnt;  // conta 0,1,2,3

    always_ff @(posedge clk) begin
        if (reset || !phy_ready) begin
            EA  <= IDLE;
            txd <= 2'b00;
            tx_ready <= 1'b0;
            tx_en <= 0;
            shift_reg <= 0;
            dibit_cnt <= 0;
        end else begin
            case (EA)
                IDLE: begin
                    tx_en <= 0;
                    tx_ready <= 1;
                    txd <= 2'b00;
                    if (txen) begin
                        EA <= LOAD;
                    end
                    else begin
                        txd  <= 2'b00;
                        EA <= IDLE;
                    end
                end

                LOAD: begin
                    tx_en <= 1;
                    shift_reg <= tx_byte;   // byte vindo do MAC TX
                    dibit_cnt <= 2'd0;
                    tx_ready <= 0;
                    EA        <= SEND;
                end

                SEND: begin
                    tx_en <= 1;
                    txd       <= shift_reg[1:0];        // pega os 2 bits menos significativos
                    shift_reg <= { 2'b00, shift_reg[7:2]}; // shift right 2 bits
                  

                    if (dibit_cnt == 2'b11) begin  // 4 dibits enviados = 1 byte completo
                        dibit_cnt <= 0;
                      EA <= WAIT;
                    end
                    else begin 
                          dibit_cnt <= dibit_cnt + 1;
                    end
                end
              WAIT: begin
                    tx_en    <= 0;
                    tx_ready <= 1;

                    if (tx_last) begin
                        EA <= IDLE;
                    end
                    else if (txen) begin
                        EA <= LOAD;
                    end
                    else begin
                        EA <= WAIT;
                    end
                end
            endcase
        end
    end
endmodule