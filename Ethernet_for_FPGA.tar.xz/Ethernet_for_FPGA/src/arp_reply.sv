module arp_reply #(
    parameter [47:0] FPGA_MAC = 48'hAA_BB_CC_DD_EE_FF,
    parameter [31:0] FPGA_IP  = {8'd192, 8'd168, 8'd1, 8'd50}
)(
    input  logic        clk,
    input  logic        reset,
    input  logic        phy_ready,
 
    // Vem do mac_rx
    input  logic [15:0] ethertype,
    input  logic [47:0] src_mac,
    input  logic [7:0]  payload_byte,
    input  logic        payload_valid,
    input  logic        payload_last,
    input  logic        frame_valid,
 
    // Para o mac_tx
    output logic        tx_start,
    output logic [47:0] tx_dst_mac,
    output logic [15:0] tx_ethertype,
    output logic [7:0]  tx_payload,
    output logic        tx_payload_valid,
    output logic        tx_payload_last,
    input  logic        tx_payload_ready,
    input  logic        tx_done
);
 

    typedef enum logic [2:0] {
        IDLE,
        RX_PAYLOAD,
        CHECK,
        TX_REPLY,
        WAIT_DONE
    } state_t;
 
    state_t     EA;
    logic [4:0] byte_cnt;
 

    logic [15:0] oper;
    logic [47:0] sha;
    logic [31:0] spa;
    logic [31:0] tpa;
 

    logic [7:0] reply_payload [0:27];
    logic [4:0] tx_idx;

    always_comb begin
        reply_payload[0]  = 8'h00; reply_payload[1]  = 8'h01; // HTYPE
        reply_payload[2]  = 8'h08; reply_payload[3]  = 8'h00; // PTYPE IPv4
        reply_payload[4]  = 8'h06;                             // HLEN
        reply_payload[5]  = 8'h04;                             // PLEN
        reply_payload[6]  = 8'h00; reply_payload[7]  = 8'h02; // OPER Reply
        reply_payload[8]  = FPGA_MAC[47:40];
        reply_payload[9]  = FPGA_MAC[39:32];
        reply_payload[10] = FPGA_MAC[31:24];
        reply_payload[11] = FPGA_MAC[23:16];
        reply_payload[12] = FPGA_MAC[15:8];
        reply_payload[13] = FPGA_MAC[7:0];
        reply_payload[14] = FPGA_IP[31:24];
        reply_payload[15] = FPGA_IP[23:16];
        reply_payload[16] = FPGA_IP[15:8];
        reply_payload[17] = FPGA_IP[7:0];
        reply_payload[18] = sha[47:40];
        reply_payload[19] = sha[39:32];
        reply_payload[20] = sha[31:24];
        reply_payload[21] = sha[23:16];
        reply_payload[22] = sha[15:8];
        reply_payload[23] = sha[7:0];
        reply_payload[24] = spa[31:24];
        reply_payload[25] = spa[23:16];
        reply_payload[26] = spa[15:8];
        reply_payload[27] = spa[7:0];
    end

    always_ff @(posedge clk) begin
        if (!reset || !phy_ready) begin
            EA               <= IDLE;
            byte_cnt         <= '0;
            tx_idx           <= '0;
            tx_start         <= 1'b0;
            tx_payload_valid <= 1'b0;
            tx_payload_last  <= 1'b0;
            oper             <= '0;
            sha              <= '0;
            spa              <= '0;
            tpa              <= '0;
        end else begin
            tx_start         <= 1'b0;
            tx_payload_valid <= 1'b0;
            tx_payload_last  <= 1'b0;
 
            case (EA)

                IDLE: begin
                    byte_cnt <= '0;
                    if (payload_valid && ethertype == 16'h0806)
                        EA <= RX_PAYLOAD;
                end
 
                RX_PAYLOAD: begin
                    if (payload_valid) begin
                        case (byte_cnt)
                            5'd6:  oper[15:8] <= payload_byte;
                            5'd7:  oper[7:0]  <= payload_byte;
                            5'd8:  sha[47:40] <= payload_byte;
                            5'd9:  sha[39:32] <= payload_byte;
                            5'd10: sha[31:24] <= payload_byte;
                            5'd11: sha[23:16] <= payload_byte;
                            5'd12: sha[15:8]  <= payload_byte;
                            5'd13: sha[7:0]   <= payload_byte;
                            5'd14: spa[31:24] <= payload_byte;
                            5'd15: spa[23:16] <= payload_byte;
                            5'd16: spa[15:8]  <= payload_byte;
                            5'd17: spa[7:0]   <= payload_byte;
                            5'd24: tpa[31:24] <= payload_byte;
                            5'd25: tpa[23:16] <= payload_byte;
                            5'd26: tpa[15:8]  <= payload_byte;
                            5'd27: tpa[7:0]   <= payload_byte;
                            default: ;
                        endcase
                        byte_cnt <= byte_cnt + 1;
                    end
 
                    if (payload_last)
                        EA <= CHECK;
                end
 
                CHECK: begin
                    if (oper == 16'h0001 && tpa == FPGA_IP) begin
                        tx_dst_mac   <= sha;
                        tx_ethertype <= 16'h0806;
                        tx_idx       <= '0;
                        tx_start     <= 1'b1;
                        EA           <= TX_REPLY;
                    end else begin
                        EA <= IDLE;
                    end
                end

                TX_REPLY: begin
                    if (tx_payload_ready || !tx_payload_valid) begin
                        tx_payload       <= reply_payload[tx_idx];
                        tx_payload_valid <= 1'b1;
                        tx_payload_last  <= (tx_idx == 5'd27);
 
                        if (tx_idx == 5'd27)
                            EA <= WAIT_DONE;
                        else
                            tx_idx <= tx_idx + 1;
                    end
                end
 
                WAIT_DONE: begin
                    tx_payload_valid <= 1'b0;
                    if (tx_done)
                        EA <= IDLE;
                end
 
                default: EA <= IDLE;
 
            endcase
        end
    end
 
endmodule 
