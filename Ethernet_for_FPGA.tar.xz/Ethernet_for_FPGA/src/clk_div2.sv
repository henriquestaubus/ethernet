module clk_div2(
    input logic clk,
    input logic reset,
    output logic clk50
);

always_ff @(posedge clk) begin
    if(reset) begin
        clk50 <= 1'b0;
    end
    else begin
        clk50 <= ~clk50;
    end
end


endmodule