module ethernet_tx_top(

    input  logic       clk,
    input  logic       reset,
    input  logic        clk50,    // 50 MHz vindo do Clocking Wizard

    input  logic       phy_ready,

    input  logic [7:0] payload_data,
    input  logic       payload_valid,
    input  logic       payload_last,

    output logic [1:0] rmii_txd,
    output logic        clkin,  // 50 MHz -> pino D5 do PHY
    output logic rmii_tx_en


);

logic [7:0] tx_byte;
logic       tx_valid;
logic       frame_done;
logic       tx_ready;


//  clk50 
//    ODDR #(
//        .DDR_CLK_EDGE ("SAME_EDGE"),
//        .INIT         (1'b0)
//    ) u_oddr_clk (
//        .Q  (clkin),  // saída para pino D5
//        .C  (clk50),
//        .CE (1'b1),
//        .D1 (1'b1),
//        .D2 (1'b0),
//        .R  (1'b0),
//        .S  (1'b0)
//    );

assign clkin = clk50;



ethernet_frame_tx frame_tx (

    .clock(clk),
    .reset(reset),

    .payload_data(payload_data),
    .payload_valid(payload_valid),
    .payload_last(payload_last),

    .tx_ready(tx_ready),

    .tx_byte(tx_byte),
    .tx_valid(tx_valid),
    .frame_done(frame_done)

);


tx_interface tx_if (

    .clk(clk),
    .reset(reset),

    .phy_ready(phy_ready),

    .txen(tx_valid),
    .tx_byte(tx_byte),
    .tx_last(frame_done),

    .tx_ready(tx_ready),

    .txd(rmii_txd)

);





endmodule