module ethernet_tx_top(

    input  logic        clk,
    input  logic        reset,

    output logic [1:0]  rmii_txd,
    output logic        clkin,  // 50 MHz -> pino D5 do PHY
    output logic        rmii_tx_en,
    output logic        resetphy
);

logic [7:0] tx_byte;
logic       tx_valid;
logic       frame_done;
logic       tx_ready;
logic       clk50;
logic [7:0] payload_data;
logic       payload_valid;
logic       payload_last;






clk_div2 div2 (
    .clk(clk),
    .reset(reset),
    .clk50(clk50)
);


assign clkin = clk50;


logic phy_reset;
logic sys_reset;
logic phy_ready;
assign sys_reset = ~phy_reset;
assign phy_ready = phy_reset; // ou a saída do módulo de reset


reset_PHY reset_PHY(
    .clk(clk50),
    .reset(reset),
    .phyreset(phy_reset)
);

assign resetphy = phy_reset;



logic [7:0] counter;

always_ff @(posedge clk50) begin
    if(sys_reset) begin
        counter <= 0;
        payload_valid <= 0;
        payload_last <= 0;
    end
    else begin
        payload_valid <= 1;
        payload_data <= counter;

        if(counter == 20) begin
            payload_last <= 1;
            counter <= 0;
        end
        else begin
            payload_last <= 0;
            counter <= counter + 1;
        end
    end
end
ethernet_frame_tx frame_tx (

    .clock(clk50),
    .reset(sys_reset),
    .phy_ready(phy_ready),

    .payload_data(payload_data),
    .payload_valid(payload_valid),
    .payload_last(payload_last),

    .tx_ready(tx_ready),

    .tx_byte(tx_byte),
    .tx_valid(tx_valid),
    .frame_done(frame_done)

);


tx_interface tx_if (

    .clk(clk50),
    .reset(sys_reset),

    .phy_ready(phy_ready),

    .txen(tx_valid),
    .tx_byte(tx_byte),
    .tx_last(frame_done),
    .tx_ready(tx_ready),
    .tx_en(rmii_tx_en),

    .txd(rmii_txd)

);

// ======================================================
// ILA Signals
// ======================================================

// ---------- ethernet_frame_tx ----------
logic [7:0] ila_tx_byte;
logic       ila_tx_valid;
logic       ila_tx_ready;
logic       ila_frame_done;

// ---------- tx_interface ----------
logic [1:0] ila_rmii_txd;
logic       ila_rmii_tx_en;
logic [1:0] ila_txif_state;

// ---------- payload ----------
logic [7:0] ila_payload_data;
logic       ila_payload_valid;
logic       ila_payload_last;

// ---------- reset / phy ----------
logic       ila_phy_ready;
logic       ila_phy_reset;
logic       ila_sys_reset;

// ---------- frame_tx FSM ----------
logic [3:0] ila_frame_state;

// ======================================================
// Assigns
// ======================================================

assign ila_tx_byte       = tx_byte;
assign ila_tx_valid      = tx_valid;
assign ila_tx_ready      = tx_ready;
assign ila_frame_done    = frame_done;

assign ila_rmii_txd      = rmii_txd;
assign ila_rmii_tx_en    = rmii_tx_en;
assign ila_txif_state    = tx_if.EA;

assign ila_payload_data  = payload_data;
assign ila_payload_valid = payload_valid;
assign ila_payload_last  = payload_last;

assign ila_phy_ready     = phy_ready;
assign ila_phy_reset     = phy_reset;
assign ila_sys_reset     = sys_reset;

// ajuste o tamanho conforme sua FSM
assign ila_frame_state   = frame_tx.EA;


// ======================================================
// ILA
// ======================================================

ila_0 ila_debug (
    .clk(clk50),

    // FRAME TX
    .probe0 (ila_tx_byte),        // [7:0]
    .probe1 (ila_tx_valid),       // [0:0]
    .probe2 (ila_tx_ready),       // [0:0]
    .probe3 (ila_frame_done),     // [0:0]

    // TX INTERFACE
    .probe4 (ila_rmii_txd),       // [1:0]
    .probe5 (ila_rmii_tx_en),     // [0:0]
    .probe6 (ila_txif_state),     // [1:0]

    // PAYLOAD
    .probe7 (ila_payload_data),   // [7:0]
    .probe8 (ila_payload_valid),  // [0:0]
    .probe9 (ila_payload_last),   // [0:0]

    // RESET / PHY
    .probe10(ila_phy_ready),      // [0:0]
    .probe11(ila_phy_reset),      // [0:0]
    .probe12(ila_sys_reset),      // [0:0]

    // FRAME FSM
    .probe13(ila_frame_state)     // [3:0]
);




endmodule