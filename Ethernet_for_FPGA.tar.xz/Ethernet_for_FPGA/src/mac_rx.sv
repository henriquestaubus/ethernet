
module mac_rx #(
    parameter [47:0] FPGA_MAC = 48'hAA_BB_CC_DD_EE_FF
)(
    input  logic        clk,
    input  logic        reset,
    input  logic        phy_ready,

    // Vem do rx_interface
    input  logic [7:0]  rx_byte,
    input  logic        rx_valid,
    input  logic        rx_last,
    input  logic        rx_error,

    // Saída para aplicação (ARP, ICMP)
    output logic [47:0] dst_mac,
    output logic [47:0] src_mac,
    output logic [15:0] ethertype,
    output logic [7:0]  payload_byte,
    output logic        payload_valid,
    output logic        payload_last,
    output logic        frame_valid
);


    typedef enum logic [2:0] {
        IDLE,
        RX_DST_MAC,
        RX_SRC_MAC,
        RX_ETHERTYPE,
        RX_PAYLOAD,
        DISCARD
    } state_t;

    state_t      EA;
    logic [2:0]  byte_cnt;  // conta bytes dentro de cada campo

    logic [47:0] dst_mac_r;
    logic [47:0] src_mac_r;
    logic [15:0] ethertype_r;
    logic        mac_ok;     // 1 se dst_mac é unicast ou broadcast


    always_ff @(posedge clk) begin
        if (!reset || !phy_ready) begin
            EA            <= IDLE;
            byte_cnt      <= '0;
            dst_mac_r     <= '0;
            src_mac_r     <= '0;
            ethertype_r   <= '0;
            dst_mac       <= '0;
            src_mac       <= '0;
            ethertype     <= '0;
            payload_byte  <= '0;
            payload_valid <= 1'b0;
            payload_last  <= 1'b0;
            frame_valid   <= 1'b0;
            mac_ok        <= 1'b0;
        end else begin
            // Defaults de pulso
            payload_valid <= 1'b0;
            payload_last  <= 1'b0;
            frame_valid   <= 1'b0;

   
            if (rx_error) begin
                EA       <= DISCARD;
                byte_cnt <= '0;
            end

            case (EA)
         
                IDLE: begin
                    byte_cnt <= '0;
                    if (rx_valid)
                        EA <= RX_DST_MAC;
                end

                RX_DST_MAC: begin
                    if (rx_valid) begin
                        // Empilha bytes do MAC destino (byte 0 = mais significativo)
                        dst_mac_r <= {dst_mac_r[39:0], rx_byte};
                        byte_cnt  <= byte_cnt + 1;

                        if (byte_cnt == 3'd5) begin
                            byte_cnt <= '0;

                            // Verifica se é unicast para o FPGA ou broadcast
                            mac_ok <= ({dst_mac_r[39:0], rx_byte} == FPGA_MAC) ||
                                      ({dst_mac_r[39:0], rx_byte} == 48'hFF_FF_FF_FF_FF_FF);

                            EA <= RX_SRC_MAC;
                        end
                    end

                    if (rx_last) EA <= IDLE; // frame curto demais
                end

        
                RX_SRC_MAC: begin
                    if (rx_valid) begin
                        src_mac_r <= {src_mac_r[39:0], rx_byte};
                        byte_cnt  <= byte_cnt + 1;

                        if (byte_cnt == 3'd5) begin
                            byte_cnt <= '0;
                            EA       <= RX_ETHERTYPE;
                        end
                    end

                    if (rx_last) EA <= IDLE;
                end

             
                RX_ETHERTYPE: begin
                    if (rx_valid) begin
                        ethertype_r <= {ethertype_r[7:0], rx_byte};
                        byte_cnt    <= byte_cnt + 1;

                        if (byte_cnt == 3'd1) begin
                            byte_cnt <= '0;

                            // Se MAC não é para nós, descarta
                            if (!mac_ok) begin
                                EA <= DISCARD;
                            end else begin
                                // Expõe campos para a camada de aplicação
                                dst_mac   <= dst_mac_r;
                                src_mac   <= src_mac_r;
                                ethertype <= {ethertype_r[7:0], rx_byte};
                                EA        <= RX_PAYLOAD;
                            end
                        end
                    end

                    if (rx_last) EA <= IDLE;
                end

                RX_PAYLOAD: begin
                    if (rx_valid) begin
                        payload_byte  <= rx_byte;
                        payload_valid <= 1'b1;
                    end

                    // Fim do frame
                    if (rx_last) begin
                        payload_last <= 1'b1;
                        frame_valid  <= 1'b1;
                        EA           <= IDLE;
                    end
                end

  
                DISCARD: begin
                    if (rx_last)
                        EA <= IDLE;
                end

                default: EA <= IDLE;

            endcase
        end
    end

endmodule 