module reset_PHY #(parameter RESET_CYCLES = 10_000_000) (
    input logic clk,
    input logic reset,
    output logic phyreset
);

logic [23:0] reset_cnt;
always_ff @(posedge clk) begin
       if(reset) begin
            reset_cnt <= 0;
            phyreset <= 1'b0;
        end
        else begin
            if(reset_cnt < RESET_CYCLES) begin
                    reset_cnt <= reset_cnt + 1;
                    phyreset <= 1'b0;
                end else begin
                    phyreset <= 1'b1;
                end
        end
    end
endmodule