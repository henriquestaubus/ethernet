module crc32_ethernet(

    input  logic       clk,
    input  logic       reset,

    input  logic [7:0] data_in,
    input  logic       data_valid,

    output logic [31:0] crc_out
);

logic [31:0] crc_reg;
logic [31:0] crc_next;

assign crc_next = crc(crc_reg, data_in);

always_ff @(posedge clk) begin

    if(reset) begin

        crc_reg <= 32'hFFFFFFFF;

    end
    else if(data_valid) begin

        crc_reg <= crc_next;

    end

end

assign crc_out = ~crc_reg;

endmodule