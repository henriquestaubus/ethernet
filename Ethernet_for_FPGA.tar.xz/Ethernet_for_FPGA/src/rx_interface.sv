module rx_interface(
    input   logic         clk,
    input   logic         reset,
    input   logic         phy_ready,  
    input   logic         crs,
    input   logic         dv,
    input   logic         rxerr,
    input   logic  [1:0]  rxd,

    output  logic  [7:0]  rx_byte, 
    output  logic         rx_valid,   
    output  logic         rx_last,    
    output  logic         rx_error    
);

assign rx_error = rxerr;

 typedef enum logic [1:0] {
        IDLE,
        RECEIVE
    } state_t;

    state_t EA;

    logic [7:0]  shift_reg;
    logic [1:0]  dibit_cnt;  // conta 0,1,2,3


    always_ff @(posedge clk) begin
        if(reset || !phy_ready) begin
            EA <= IDLE;
            rx_byte <= 0;
            rx_valid <= 0;
        end else begin

            rx_valid <= 1'b0; // pulso de 1 ciclo
            rx_last  <= 1'b0;


             case (EA)
                IDLE: begin
                    dibit_cnt <= 0;
                    if (dv) begin
                        EA <= RECEIVE;
                    end
                end

                RECEIVE: begin
      
                    shift_reg <= {shift_reg[5:0], rxd};
                    dibit_cnt <= dibit_cnt + 1;

                    if (dibit_cnt == 2'b11) begin
                        rx_byte  <= {shift_reg[5:0], rxd};
                        rx_valid <= 1'b1;
                        dibit_cnt <= '0;
                    end

                    if (!crs) begin
                        rx_last <= 1'b1;
                        EA      <= IDLE;
                    end
                end

                default: EA <= IDLE;

            endcase
        end
    end


endmodule //rx_interface