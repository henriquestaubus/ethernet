module rmii_phy_ctrl (
    input  logic        clk,      // 100 MHz sistema
    input  logic        clk50,    // 50 MHz vindo do Clocking Wizard
    input  logic        reset,
    output logic        clkin,    // 50 MHz -> pino D5 do PHY
    output logic        resetphy, // -> pino B3 do PHY
    output logic [1:0]  txd,
    output logic        txen,
    input  logic [1:0]  rxd,
    input  logic        crs_dv,
    input  logic        rxerr
);

    // Leva o clk50 ao pino físico via ODDR
    ODDR #(
        .DDR_CLK_EDGE ("SAME_EDGE"),
        .INIT         (1'b0)
    ) u_oddr_clk (
        .Q  (clkin),  // saída para pino D5
        .C  (clk50),
        .CE (1'b1),
        .D1 (1'b1),
        .D2 (1'b0),
        .R  (1'b0),
        .S  (1'b0)
    );

    logic crs, dv;

    IDDR #(
        .DDR_CLK_EDGE ("SAME_EDGE_PIPELINED")
    ) u_iddr_crsdv (
        .Q1 (dv),       // capturado na borda de subida
        .Q2 (crs),      // capturado na borda de descida
        .C  (clk50),
        .CE (1'b1),
        .D  (crs_dv),
        .R  (1'b0),
        .S  (1'b0)
    );

    // Reset do PHY — segurar baixo por ~100ms depois soltar
    
logic phy_reset;
logic phy_ready;
assign phy_ready = phy_reset; // ou a saída do módulo de reset


reset_PHY reset_PHY(
    .clk(clk),
    .reset(reset),
    .phyreset(phy_reset)
);

assign resetphy = phy_reset;

    // TX Interface
    logic [1:0] txd_int;
    logic       txen_int;

tx_interface tx_interface(
    .clk(clk50),
    .reset(reset),
    .phy_ready(phy_ready),
    .txen(txen_int),
    .txd(txd_int)
);

    assign txd  = txd_int;
    assign txen = txen_int;
    

endmodule